# Handoff: Aurora Voice Overlay — Reactive Icon + Draggable Popups

## Overview
This bundle covers the floating "Aurora" assistant overlay: a voice-mode indicator (an animated owl icon that reacts to audio) and a text-chat popup, both anchored over a host app window. This handoff focuses on two features built in this session:

1. **Voice-reactive icon animation** — the owl badge glows, brightens, scales, and shows a rotating "sweep" highlight that responds live to audio level (real microphone input when available, with a graceful synthetic fallback).
2. **Draggable popups** — both the voice-orb popup and the text-chat popup can be dragged anywhere on screen via a small grip handle, and reset to their default docked position.

## About the Design Files
The file in this bundle (`Aurora Overlay.dc.html`) is a **design reference prototype**, built in a custom HTML component format for our design tool — it is NOT production code and should not be copied/pasted as-is. Read it to understand exact structure, styling values, and behavior, then **recreate the design in the target codebase's existing environment** (React, Vue, SwiftUI, native, etc.), using that codebase's component patterns, state management, and design-system primitives. If the codebase doesn't yet have a settled UI framework, pick the most appropriate one and implement there.

The prototype uses a design system called "Aurora" (dark cockpit-style UI kit) for buttons/tabs/badges/etc. If the target codebase has its own design system, use its equivalent components and tokens instead of trying to match the Aurora kit pixel-for-pixel — the priority is matching layout, motion, and interaction behavior described below.

## Fidelity
**High-fidelity.** Colors, sizes, animation timings, and interaction behavior below should be recreated closely. Copy/microcopy is illustrative demo content (e.g. meeting transcript text) and can be replaced with real data.

## Screens / Views

### 1. Voice orb popup (top-right)
Appears when voice mode is active (states: `connecting` → `listening` → `speaking`, or `muted`). Anchored `top: 28px; right: 32px` over the host stage by default, draggable from there.

**Layout** (column, centered, gap 8px):
- Drag handle: 3 small dots (grip), full width, `cursor: grab`, sits just above the close button
- Close button (×): 24×24px circle, `background: rgba(0,0,0,.15)`, top-right of the stack
- Orb button: 106×106px, transparent, no border, contains:
  - `<img>` of the owl icon (`assets/aurora-owl.png`), 106×106, `object-fit: contain`, `border-radius: 999px`
  - A sweep overlay `<div>` the **same size/position** as the icon (absolutely positioned `inset: -6px`), showing a rotating conic-gradient arc masked into a ring band, so it sits exactly on top of the icon's own baked-in decorative ring (see Animations below)
  - When muted: small 24×24 mute-slash badge, bottom-right corner of the orb
- Status label below the orb: pill-shaped chip, `background: #ffffffcc`, text one of "Connecting…" / "Listening" / "Speaking" / "Muted", centered under the orb

**Interaction**: clicking the orb cycles demo states (listening → speaking → muted → listening); in production this should reflect real voice-pipeline state instead.

### 2. Text chat popup (bottom-center)
Appears on ⌘K/Ctrl+K or via the mic icon in the input bar. Anchored `bottom: 28px`, horizontally centered by default, draggable.

**Layout** (column, gap 8px, width 480px):
- Drag handle: same 3-dot grip, centered, sits just above the message history
- Optional message history (scrollable, max-height 230px): user bubbles right-aligned (`#202327` bg, white text), assistant bubbles left-aligned (`#131518` bg, bordered), "Thinking…" bubble while awaiting a reply
- Input pill bar: dark rounded bar (`#15171a`, border `#ffffff17`, `border-radius: 999px`) containing: voice-mode icon button, text input, send button, "start meeting notes" button, pin button, settings dropdown, close (×) button

## Interactions & Behavior

### Voice-reactive animation
- Drives off **live microphone input** via `getUserMedia` + `AnalyserNode` (`fftSize: 64`) whenever state is `listening`. If mic permission is denied/unavailable, falls back to a **synthetic speech-like envelope** (sine-based, randomized) so the animation still looks alive.
- For `speaking` state (assistant's own audio), always uses the synthetic envelope (no mic needed) — this should be swapped for real playback-amplitude analysis of the TTS/audio output stream in production.
- Every animation frame, computes a single `level` value (0–1) representing current audio amplitude, then:
  - Icon `filter`: `brightness(1 + level*0.55) saturate(1 + level*0.7) drop-shadow(0 0 (8 + level*34)px <state-color>)` — color is cyan `rgba(26,209,209,…)` for listening/idle, blue `rgba(55,170,227,…)` for speaking, gray for muted
  - Icon `transform`: `scale(1 + level*0.14)` — subtle pulse tied to loudness
  - Sweep overlay opacity: `muted → 0.1`, else `0.45 + level*0.65`
- Sweep overlay is a `conic-gradient` ring (bright arc from ~300°–345°, rest transparent) masked with a `radial-gradient` (`mask`/`-webkit-mask`) so only a ring band shows, continuously rotating via CSS `@keyframes` (`orbSweepRotate`, `transform: rotate(360deg)`), full 360° loop. Rotation speed: 2.4s (speaking) / 5s (listening) / 18s (idle/muted) — linear, infinite.
- Implementation note: don't add a *second*, independently-positioned ring around the icon — early iteration did this and it visually desynced from the ring baked into the icon artwork. Keep the sweep overlay pinned to the exact same box as the icon so it's always concentric.
- Animation loop runs via `requestAnimationFrame`, mutating DOM refs directly (icon/sweep element styles) rather than through state/re-render, to stay smooth at 60fps.
- Mic stream is started when entering `listening` and always torn down (tracks stopped, AudioContext closed) when leaving that state or on unmount — don't leave a hot mic stream running.

### Dragging
- Each popup has a small 3-dot grip handle (14px tall row) as its own drag affordance — clicking and dragging *elsewhere* in the popup (buttons, input, text) does not start a drag (checked via `event.target.closest('button, input, textarea')` — click targets inside interactive elements are ignored).
- Drag delta is tracked from `mousedown` on the grip through `mousemove`/`mouseup` on `window`, and stored as an `{x, y}` offset added on top of the popup's default docked position via CSS `transform: translate(...)`.
- A "Reset" action (already present in the prototype's demo toolbar) clears both popups' drag offsets back to `{x: 0, y: 0}`, restoring default docked positions.
- Positions are not currently persisted — consider persisting per-popup offsets (e.g. localStorage) if users expect the overlay to "stay put" between sessions.

## State Management
Relevant state (see `Aurora Overlay.dc.html`'s logic class for the reference shape):
- `voice`: `null | 'connecting' | 'listening' | 'speaking' | 'muted'`
- `voicePos`, `textPos`: `{x: number, y: number}` — drag offsets for each popup
- `textOpen`: boolean — chat popup visibility
- `pinned`: boolean — keeps popup open through Escape
- Standard chat state: `input`, `history[]`, `thinking`

State transitions:
- `listening` state mount → start mic capture; unmount/leave → stop mic capture
- Any `mousedown` on a grip → begin a drag session scoped to that popup only

## Design Tokens
- Cyan accent (listening/idle): `#1ad1d1`
- Blue accent (speaking): `#37aae3` / sweep highlight `#6fe3ff`
- Muted gray: `#5b5f63` / `#8e9398`
- Dark surfaces: `#131518`, `#15171a`, `#1d2023`, `#202327`
- Border hairline: `#ffffff17`
- Popup shadow: `0 16px 40px rgba(0,0,0,.4)`
- Corner radii: `999px` for pills/circles, `14px`/`4px` mix for chat bubble tails
- Font: `'Geist', system-ui, sans-serif`; body copy 12.5–14px, labels 10–11px uppercase-tracked

## Assets
- `assets/aurora-owl.png` — the Aurora owl badge icon (transparent PNG, 500×500 source). This already contains a baked-in decorative ring/arc pattern around the owl face — the sweep animation is designed to sit exactly on top of that existing ring, not add a new one.

## Files
- `Aurora Overlay.dc.html` — full prototype (voice orb + chat popup + meeting-companion panel demo). Search for `sweepRef`, `iconRef`, `_tickLoop`, `_startMic`, `_startDrag` in the embedded logic class for the exact reference implementation of the two features covered here.
